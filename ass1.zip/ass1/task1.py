from turtle import pd
import pandas as a pd
# Read in data and examine first 10 rows
jsrt_metadata= pd.read_csv('data/formatted_jsrt_metadata.csv')
jsrt_metadata.head(10)


import matplotlib.pyplot as plt
import seaborn as sns


plt.hist(jsrt_metadata['arr_delay'], 
         bins = int(180/5))